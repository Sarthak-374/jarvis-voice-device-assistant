package com.jarvis.companion

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

/**
 * UI Element Detector resolving natural language target queries to AccessibilityNodeInfo.
 */
class UIElementDetector(private val service: AccessibilityService) {

    companion object {
        private const val TAG = "JARVIS_UIElementDetector"
    }

    fun findNodeByText(query: String): AccessibilityNodeInfo? {
        val root = service.rootInActiveWindow ?: return null
        val matchedNodes = root.findAccessibilityNodeInfosByText(query)

        if (!matchedNodes.isNullOrEmpty()) {
            Log.d(TAG, "Found ${matchedNodes.size} matching nodes for query: '$query'")
            return matchedNodes[0]
        }

        // Deep search fallback
        return searchTree(root, query.lowercase())
    }

    private fun searchTree(node: AccessibilityNodeInfo, queryLower: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase()
        val desc = node.contentDescription?.toString()?.lowercase()

        if ((text != null && text.contains(queryLower)) || (desc != null && desc.contains(queryLower))) {
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = searchTree(child, queryLower)
            if (found != null) return found
        }
        return null
    }

    fun getNodeClickCenter(node: AccessibilityNodeInfo): Pair<Float, Float> {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val centerX = rect.exactCenterX()
        val centerY = rect.exactCenterY()
        return Pair(centerX, centerY)
    }
}
