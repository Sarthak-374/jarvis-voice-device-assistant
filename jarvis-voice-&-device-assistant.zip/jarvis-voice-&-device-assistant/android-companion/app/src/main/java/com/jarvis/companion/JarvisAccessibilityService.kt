package com.jarvis.companion

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.gson.JsonObject

/**
 * Main Android Accessibility Service implementation for JARVIS Voice & Device Assistant.
 * Receives remote action commands via BridgeClient and executes real hardware & gesture actions.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JARVIS_AccessibilityService"
        var instance: JarvisAccessibilityService? = null
            private set
    }

    private lateinit var actionExecutor: ActionExecutor
    private lateinit var appLauncher: AppLauncher
    private lateinit var screenReader: ScreenReader
    private lateinit var uiElementDetector: UIElementDetector
    private var bridgeClient: BridgeClient? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        actionExecutor = ActionExecutor(this)
        appLauncher = AppLauncher(this)
        screenReader = ScreenReader(this)
        uiElementDetector = UIElementDetector(this)

        Log.i(TAG, "JARVIS Accessibility Service connected successfully.")

        // Initialize Bridge Client and poll commands
        bridgeClient = BridgeClient().apply {
            startPolling { commandJson ->
                handleCommand(commandJson)
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observe screen window content changes for multi-modal context
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        bridgeClient?.stopPolling()
        instance = null
        Log.i(TAG, "JarvisAccessibilityService destroyed")
    }

    fun handleCommand(cmd: JsonObject) {
        val action = cmd.get("action")?.asString?.uppercase() ?: return
        val target = cmd.get("target")?.asString ?: ""

        Log.d(TAG, "Executing Action [$action] on Target [$target]")

        when (action) {
            "TAP" -> {
                val coords = parseCoordinates(target)
                if (coords != null) {
                    actionExecutor.dispatchTap(coords.first, coords.second)
                } else {
                    val node = uiElementDetector.findNodeByText(target)
                    if (node != null) {
                        val center = uiElementDetector.getNodeClickCenter(node)
                        actionExecutor.dispatchTap(center.first, center.second)
                    }
                }
            }

            "LONG_PRESS" -> {
                val coords = parseCoordinates(target)
                if (coords != null) {
                    actionExecutor.dispatchLongPress(coords.first, coords.second)
                }
            }

            "SWIPE" -> {
                actionExecutor.dispatchSwipe(540f, 1800f, 540f, 600f)
            }

            "TYPE_TEXT" -> {
                val textToType = cmd.getAsJsonObject("parameters")?.get("text")?.asString ?: target
                actionExecutor.typeTextIntoFocusedNode(textToType)
            }

            "BACK" -> {
                actionExecutor.performGlobalAction(GLOBAL_ACTION_BACK)
            }

            "HOME" -> {
                actionExecutor.performGlobalAction(GLOBAL_ACTION_HOME)
            }

            "OPEN_APP" -> {
                appLauncher.launchAppByName(target)
            }

            "SCROLL" -> {
                actionExecutor.performScroll(forward = true)
            }

            else -> {
                Log.w(TAG, "Unsupported or unknown action: $action")
            }
        }
    }

    private fun parseCoordinates(str: String): Pair<Float, Float>? {
        return try {
            if (str.contains("x:") && str.contains("y:")) {
                val parts = str.split(",")
                val x = parts[0].replace("x:", "").trim().toFloat()
                val y = parts[1].replace("y:", "").trim().toFloat()
                Pair(x, y)
            } else if (str.contains(",")) {
                val parts = str.split(",")
                Pair(parts[0].trim().toFloat(), parts[1].trim().toFloat())
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
