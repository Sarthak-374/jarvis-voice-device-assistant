package com.jarvis.companion

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Low-level Action Executor executing real Android hardware & accessibility gestures.
 * Supports: TAP, LONG_PRESS, SWIPE, TYPE_TEXT, BACK, HOME, OPEN_APP, SCROLL.
 */
class ActionExecutor(private val service: AccessibilityService) {

    companion object {
        private const val TAG = "JARVIS_ActionExecutor"
    }

    fun dispatchTap(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        Log.d(TAG, "Dispatching TAP gesture at ($x, $y)")
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "TAP completed successfully at ($x, $y)")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.e(TAG, "TAP gesture cancelled at ($x, $y)")
                callback?.invoke(false)
            }
        }, null)
    }

    fun dispatchLongPress(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        Log.d(TAG, "Dispatching LONG_PRESS gesture at ($x, $y)")
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 1000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "LONG_PRESS completed at ($x, $y)")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.e(TAG, "LONG_PRESS cancelled")
                callback?.invoke(false)
            }
        }, null)
    }

    fun dispatchSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300, callback: ((Boolean) -> Unit)? = null) {
        Log.d(TAG, "Dispatching SWIPE gesture from ($startX, $startY) to ($endX, $endY)")
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "SWIPE gesture completed")
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.e(TAG, "SWIPE gesture cancelled")
                callback?.invoke(false)
            }
        }, null)
    }

    fun typeTextIntoFocusedNode(text: String): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val focusedNode = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

        return if (focusedNode != null) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            val result = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            focusedNode.recycle()
            Log.d(TAG, "TYPE_TEXT performed with result: $result")
            result
        } else {
            Log.w(TAG, "No focused input node found to perform TYPE_TEXT")
            false
        }
    }

    fun performGlobalAction(action: Int): Boolean {
        val actionName = when (action) {
            AccessibilityService.GLOBAL_ACTION_BACK -> "GLOBAL_ACTION_BACK"
            AccessibilityService.GLOBAL_ACTION_HOME -> "GLOBAL_ACTION_HOME"
            AccessibilityService.GLOBAL_ACTION_RECENTS -> "GLOBAL_ACTION_RECENTS"
            else -> "ACTION_$action"
        }
        Log.d(TAG, "Performing Global Action: $actionName")
        return service.performGlobalAction(action)
    }

    fun performScroll(forward: Boolean = true): Boolean {
        val rootNode = service.rootInActiveWindow ?: return false
        val scrollableNode = findScrollableNode(rootNode)

        return if (scrollableNode != null) {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            val res = scrollableNode.performAction(action)
            scrollableNode.recycle()
            Log.d(TAG, "SCROLL performed with result: $res")
            res
        } else {
            Log.w(TAG, "No scrollable container found in active screen window")
            false
        }
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findScrollableNode(child)
            if (result != null) return result
        }
        return null
    }
}
