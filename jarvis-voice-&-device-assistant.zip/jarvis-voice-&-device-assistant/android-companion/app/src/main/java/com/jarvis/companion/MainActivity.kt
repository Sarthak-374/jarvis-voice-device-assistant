package com.jarvis.companion

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * JARVIS Companion App Main Dashboard & Setup Activity.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnEnableAccessibility: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Simple programmatically created layout
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            setBackgroundColor(0xFF0F172A.toInt()) // Slate 900
        }

        val tvTitle = TextView(this).apply {
            text = "JARVIS ANDROID COMPANION"
            textSize = 20f
            setTextColor(0xFF06B6D4.toInt()) // Cyan 500
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        tvStatus = TextView(this).apply {
            text = "Checking Accessibility Service status..."
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt()) // Slate 400
            setPadding(0, 32, 0, 48)
        }

        btnEnableAccessibility = Button(this).apply {
            text = "Enable Accessibility Service"
            setBackgroundColor(0xFF0284C7.toInt()) // Sky 600
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        layout.addView(tvTitle)
        layout.addView(tvStatus)
        layout.addView(btnEnableAccessibility)

        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val isConnected = JarvisAccessibilityService.instance != null
        if (isConnected) {
            tvStatus.text = "STATUS: ONLINE & CONNECTED\nAccessibility Service is Active.\nListening for commands from JARVIS Web App."
            tvStatus.setTextColor(0xFF10B981.toInt()) // Emerald 500
            btnEnableAccessibility.text = "Accessibility Service Active"
            btnEnableAccessibility.isEnabled = false
        } else {
            tvStatus.text = "STATUS: DISCONNECTED\nAndroid Accessibility Service Required.\nTap button below to grant permission in Settings."
            tvStatus.setTextColor(0xFFF59E0B.toInt()) // Amber 500
            btnEnableAccessibility.text = "Open Accessibility Settings"
            btnEnableAccessibility.isEnabled = true
        }
    }
}
