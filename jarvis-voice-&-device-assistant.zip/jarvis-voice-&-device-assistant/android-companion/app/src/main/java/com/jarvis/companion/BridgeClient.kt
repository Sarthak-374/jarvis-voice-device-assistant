package com.jarvis.companion

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Secure HTTP/WebSocket Bridge Client polling commands from JARVIS Web App backend.
 * Uses strict pairing token authentication and error recovery.
 */
class BridgeClient(
    private val serverUrl: String = "https://ais-dev-ibwummtw4wizxrxvdzoxic-154732699573.asia-southeast1.run.app",
    private val pairingToken: String = "JARVIS-8890-ANDROID"
) {

    companion object {
        private const val TAG = "JARVIS_BridgeClient"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private var isPolling = false
    private var onCommandReceived: ((JsonObject) -> Unit)? = null

    fun startPolling(onCommand: (JsonObject) -> Unit) {
        this.onCommandReceived = onCommand
        if (isPolling) return
        isPolling = true

        Log.i(TAG, "Starting secure command polling from JARVIS server: $serverUrl")

        CoroutineScope(Dispatchers.IO).launch {
            // Step 1: Pair with Server
            pairWithServer()

            // Step 2: Poll commands loop
            while (isPolling) {
                try {
                    pollCommands()
                } catch (e: Exception) {
                    Log.e(TAG, "Polling error: ${e.message}")
                }
                delay(1500) // Poll every 1.5s
            }
        }
    }

    private fun pairWithServer() {
        try {
            val json = JsonObject().apply {
                addProperty("token", pairingToken)
                addProperty("deviceModel", android.os.Build.MODEL)
                addProperty("androidVersion", "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
                addProperty("accessibilityGranted", true)
            }

            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$serverUrl/api/android/pair")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                Log.d(TAG, "Pair response code: ${response.code}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to pair with JARVIS server", e)
        }
    }

    private fun pollCommands() {
        val request = Request.Builder()
            .url("$serverUrl/api/android/commands")
            .header("X-Pairing-Token", pairingToken)
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val bodyStr = response.body?.string() ?: return
                val json = gson.fromJson(bodyStr, JsonObject::class.java)
                val commandsArray = json.getAsJsonArray("commands")

                if (commandsArray != null && commandsArray.size() > 0) {
                    for (elem in commandsArray) {
                        val cmdObj = elem.asJsonObject
                        Log.i(TAG, "Received command: ${cmdObj.get("action").asString}")
                        onCommandReceived?.invoke(cmdObj)
                    }
                }
            }
        }
    }

    fun stopPolling() {
        isPolling = false
    }
}
