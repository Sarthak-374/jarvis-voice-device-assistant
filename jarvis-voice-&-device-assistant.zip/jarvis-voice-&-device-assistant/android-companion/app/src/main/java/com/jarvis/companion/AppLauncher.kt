package com.jarvis.companion

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log

/**
 * App Launcher service for launching installed Android packages via Intents.
 */
class AppLauncher(private val context: Context) {

    companion object {
        private const val TAG = "JARVIS_AppLauncher"
    }

    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                Log.d(TAG, "Successfully launched package: $packageName")
                true
            } else {
                Log.w(TAG, "Package not found or no launch intent: $packageName")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error launching app: $packageName", e)
            false
        }
    }

    fun launchAppByName(appNameQuery: String): Boolean {
        val packageName = resolvePackageName(appNameQuery)
        return if (packageName != null) {
            launchAppByPackage(packageName)
        } else {
            Log.w(TAG, "Could not resolve package name for query: $appNameQuery")
            false
        }
    }

    fun resolvePackageName(query: String): String? {
        val lower = query.lowercase().trim()
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val apps = pm.queryIntentActivities(mainIntent, 0)
        for (app in apps) {
            val label = app.loadLabel(pm).toString().lowercase()
            if (label.contains(lower) || lower.contains(label)) {
                return app.activityInfo.packageName
            }
        }

        // Common hardcoded fallbacks
        return when {
            lower.contains("youtube") -> "com.google.android.youtube"
            lower.contains("whatsapp") -> "com.whatsapp"
            lower.contains("instagram") -> "com.instagram.android"
            lower.contains("chrome") -> "com.android.chrome"
            lower.contains("camera") -> "com.android.camera2"
            lower.contains("setting") -> "com.android.settings"
            else -> null
        }
    }
}
