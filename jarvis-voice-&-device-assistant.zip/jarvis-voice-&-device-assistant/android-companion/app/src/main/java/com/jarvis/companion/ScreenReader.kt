package com.jarvis.companion

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

data class AccessibilityNodeModel(
    val id: String,
    val text: String?,
    val contentDescription: String?,
    val className: String,
    val bounds: Rect,
    val isClickable: Boolean,
    val isScrollable: Boolean
)

/**
 * Screen Reader utility capturing active screen hierarchy and element text nodes.
 */
class ScreenReader(private val service: AccessibilityService) {

    companion object {
        private const val TAG = "JARVIS_ScreenReader"
    }

    fun dumpActiveScreenNodes(): List<AccessibilityNodeModel> {
        val rootNode = service.rootInActiveWindow ?: return emptyList()
        val nodesList = mutableListOf<AccessibilityNodeModel>()

        traverseNode(rootNode, nodesList)
        Log.d(TAG, "Dumped ${nodesList.size} nodes from active window hierarchy")
        return nodesList
    }

    private fun traverseNode(node: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeModel>) {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val model = AccessibilityNodeModel(
            id = node.viewIdResourceName ?: "node_${System.currentTimeMillis()}",
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            className = node.className?.toString() ?: "android.view.View",
            bounds = bounds,
            isClickable = node.isClickable,
            isScrollable = node.isScrollable
        )
        list.add(model)

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, list)
        }
    }
}
